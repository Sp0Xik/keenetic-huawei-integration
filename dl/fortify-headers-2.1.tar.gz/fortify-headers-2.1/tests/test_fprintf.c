#include "common.h"

#include <stdio.h>

int main(int argc, char** argv) {
  fprintf(stdout, "%s", "1234567");
}
