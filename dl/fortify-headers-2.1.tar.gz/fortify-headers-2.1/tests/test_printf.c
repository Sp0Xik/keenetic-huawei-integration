#include "common.h"

#include <stdio.h>

int main(int argc, char** argv) {
  printf("%s", "1234567");
}
